public class AC201 {
    public static void main(String[] args) {
        
        boolean isOccupied = false;
        System.out.println(isOccupied);
        
        char lastKeyPressed = 'M';
        System.out.println(lastKeyPressed);
       
        long pago = 500000l;
        System.out.println(pago);
       
        byte numero = 101;
        System.out.println(numero);
       
        short precioCoche = 21345;
        System.out.println(precioCoche);
       
        byte cantidadCoche = 3; 
        System.out.println(cantidadCoche);
        
        char scapedKey = '\t'; 
        System.out.println(scapedKey);
       
        long calculoVelocidad = 8999565321456l;
        System.out.println(calculoVelocidad);

        String language = "java";
        System.out.println(language);

        double impuesto = 2.98;
        System.out.println(impuesto);

        double peso1 = 67.5;
        System.out.println(peso1);

        double peso2 = 42.33;
        System.out.println(peso2);

        String centro = "Severo Ochoa";
        System.out.println(centro);

        double peso3 = 77.125;
        System.out.println(peso3);

        byte edad = 55;
        System.out.println(edad);

        //char símbolo = '☠️'
        //System.out.printIn(símbolo);

        byte totalCoches = cantidadCoche;
       System.out.println(totalCoches); 

        double totalPeso = peso1 + peso2 + peso3;
        System.out.println(totalPeso);

        double pesoMedio = totalPeso / 3;
        System.out.println(pesoMedio);
        
    }
}