
public class AC314 {
    public static void main(String[] args) {
    int i;
    for (i = 1; i < 10; i += 2){
        System.out.println(i);
      }
    System.out.println("_____");
         for (int j = 1; j <= 16; j = j*2){
        System.out.println(j);
    }
    }
}
   

