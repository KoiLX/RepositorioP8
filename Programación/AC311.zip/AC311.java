public class AC311 {
    public static void main(String[] args) {
    int valor = 0;
    /** 
     * @author Sergio Bailén Sampere
     * @version 1.0
     * Desarrolla un programa utilizando un bucle do-while que imprima “Hola caracola” 5 veces.
     * hacemos que en el "do" nos imprima en terminal hola caracola, y que suba el valor en 1 cada vez
     * que pasa por él.
     * En el while ponemos como condicion para que salga del bucle que sea mayor que 5 para
     * que nos imprima 5 hola caracola
     */
    do {
        System.out.println("Hola caracola");
        valor++;

    } while(valor  < 5);
    }
    
}
